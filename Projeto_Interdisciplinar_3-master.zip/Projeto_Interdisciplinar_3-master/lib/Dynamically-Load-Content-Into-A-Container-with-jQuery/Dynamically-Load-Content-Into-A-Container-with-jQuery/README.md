<h1>jQuery Dynamic Load Content</h1>

<!--p>.load().</p-->
<a href="http://www.pablogarciafernandez.com/lab/demo/jQuery-Dynamic-Load-Content/index.html" target="_blank">Check out the demo page</a>.

<h2>Download, Fork, Commit.</h2>

<p>If you think you can make this better, please Download, Fork, &amp; Commit. I'd love to see your ideas.</p>

<h2>License</h2>

<p>You should add this comment to the beginning of the CSS and JavaScript code of this plugin:
<pre>
/*	
	jQuery Dynamic Load Content
	===================
	License:
	http://goo.gl/e537nC
	===================
	Author: @PableraShow

*/
</pre>
And add another comment when finish the CSS and JavaScript code plugin:
<pre>
/*	
	End of the jQuery Dynamic Load Content
	===================
	Author: @PableraShow

*/
</pre></p>

===================

<a href="http://pablogarciafernandez.com" title="Pablo García Fernández" target="_blank">Pablo García Fernández</a>

